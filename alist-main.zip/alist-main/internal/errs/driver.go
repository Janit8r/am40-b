package errs

import "errors"

var (
	EmptyToken = errors.New("empty token")
)
